import React, {Component} from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Route } from 'react-router-dom';
import Login from './Containers/Login/Login';
import Dashboard from './Containers/Dashboard/Dashboard';
import FourZeroFour from './Containers/Errors/FourZeroFour';
import ChangePassword from './Containers/ChangePassword/ChangePassword';
import AdminsTable from './Containers/Tables/AdminsTable';
import AddEmployee from './Containers/Employees/AddEmployee';
import EmployeesTable from './Containers/Tables/EmployeesTable';
const globalNames = 
{
  APPURL : 'http://localhost:3000/'
}
class App extends Component
{
  constructor(props) 
  {
    super(props);
    this.state = {
      am_id : ''
    };
  }
   render()
   {
     return (
      <BrowserRouter>
      <Route exact path="/admin/login" component={Login} />
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/dashboard/:adminid" component={Dashboard} /> : <FourZeroFour/>
      }
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/change-password" component={ChangePassword} /> : ''
      }
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/admins-list" component={AdminsTable} /> : ''
      }
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/add-employee" component={AddEmployee} /> : ''
      }
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/employees-list/0" component={EmployeesTable} /> : ''
      }
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/employees-list/1" component={EmployeesTable} /> : ''
      }
      { 
      (localStorage.getItem('adminid')!=null || window.location.href==globalNames.APPURL+'admin/login') ? 
          <Route exact path="/admin/employees-list/2" component={EmployeesTable} /> : ''
      }
      </BrowserRouter>
     );
   }
}
export default App;
