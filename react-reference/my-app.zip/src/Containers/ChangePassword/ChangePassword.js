import React, { Component } from 'react';
import axios from 'axios';
import Navbar1 from '../Navbars/Navbar1';
import Navbar2 from '../Navbars/Navbar2';
import ChangePasswordHeader from '../Headers/ChangePasswordHeader';
const globalNames = {
    APPURL : 'http://localhost:1234/'
}
class ChangePassword extends Component
{
    constructor(props) {
        super(props);
        this.state = {
          am_oldpassword: '',
          am_newpassword: '',
          am_confirmpassword : '',
          am_passwordChanged : '',
          am_id : localStorage.getItem('adminid')
        };
    }
    handleInputChange = e => {
        this.setState({
          [e.target.name]: e.target.value,
        });
    };
    handleSubmit = e => {
        e.preventDefault();
        const { am_oldpassword, am_newpassword, am_confirmpassword, am_id } = this.state;
        const passwords = {
            am_oldpassword,
            am_newpassword,
            am_confirmpassword,
            am_id,
            token : localStorage.getItem("admintoken")
        };
        if(passwords.am_newpassword!=passwords.am_confirmpassword)
        {
            alert("New Passwords do not match!!");
            return false;
        }
        return axios
          .patch(globalNames.APPURL+'admin/update-password', { ...passwords },{
            header: {
                'Content-Type': 'application/json'
            }
        })
          .then((res) => {
            if(res.data.password=="1"){
              this.setState({
                am_passwordChanged : "Password Changed Successfully.."
              })
            }else{
                this.setState({
                    am_passwordChanged : "Old Password is Incorrect"
                })
            }
          })
          .catch(err => {
            console.error(err);
          });
      };
    render()
    {
        return (
            <div id="wrapper">
                <Navbar1 am_username={localStorage.getItem("adminusername")}/>
                <Navbar2/>
            <div id="page-wrapper">
                <ChangePasswordHeader/>
            <div id="page-inner">
            <div className="row">
            <div className="col-lg-12">
                <div className="card">
                <div className="card-action">
                    Change Password Form
                </div>
                {
                        (this.state.am_passwordChanged) ? 
                        <div class="alert alert-warning">
                        {this.state.am_passwordChanged}.
                        </div> : ''
                }
                <div className="card-content">
                    <form onSubmit={(e)=>this.handleSubmit(e)} className="col s12">
                    <div className="row">
                        <div className="input-field col s12">
                        <input id="first_name" type="password" name="am_oldpassword" required onChange={this.handleInputChange} className="validate" required/>
                        <label htmlFor="first_name">Old Password</label>
                        </div>
                        <div className="input-field col s12">
                        <input id="last_name" type="password" name="am_newpassword" required onChange={this.handleInputChange} className="validate" required/>
                        <label htmlFor="last_name">New Password</label>
                        </div>
                        <div className="input-field col s12">
                        <input id="last_name" type="password" name="am_confirmpassword" required onChange={this.handleInputChange} className="validate" required/>
                        <label htmlFor="last_name">Confirm Password</label>
                        </div>
                        <div className="input-field col s12">
                        <input id="submit" type="submit" className="validate" />
                        </div>
                    </div>
                    </form>
                    <div className="clearBoth" />
                </div>
                </div>
            </div>	
            </div>
            </div>
            </div>
            </div>
        );
    }
}
export default ChangePassword;