import React, { Component } from 'react';
import axios from 'axios';
import Navbar1 from '../Navbars/Navbar1';
import Navbar2 from '../Navbars/Navbar2';
import DashboardHeader from '../Headers/DashboardHeader';
import DashboardCards from '../Cards/DashboardCards';
const globalNames = {
    APPURL : 'http://localhost:1234/'
}
class Dashboard extends Component
{
    constructor(props) {
        super(props);
        this.state = {
          totalempcount : '',
          activeempcount : '',
          inactiveempcount : '',
          admincount : ''
        };
    }
    componentDidMount(){
        return axios
        .get(globalNames.APPURL+'admin/dashboard/'+localStorage.getItem("adminid") ,{
          header: {
              'Content-Type': 'application/json',
              'token' : localStorage.getItem("admintoken")
          }
    })
        .then((res) => {  
            this.setState({
              totalempcount : res.data[0]["0"].totalempcount,
              activeempcount : res.data[1]["0"].activeempcount,
              inactiveempcount : res.data[2]["0"].inactiveempcount,
              admincount : res.data[3]["0"].admincount
            });
        })
        .catch(err => {
          console.error(err);
        });
    }
    render()
    {
        return (
            <div id="wrapper">
                <Navbar1 am_username={localStorage.getItem("adminusername")}/>
                <Navbar2/>
            <div id="page-wrapper">
                <DashboardHeader/>
            <div id="page-inner">
                <DashboardCards activeempcount={this.state.activeempcount} inactiveempcount={this.state.inactiveempcount} admincount={this.state.admincount} totalempcount={this.state.totalempcount}/>
            </div>
            </div>
            </div>
        );
    }
}
export default Dashboard;