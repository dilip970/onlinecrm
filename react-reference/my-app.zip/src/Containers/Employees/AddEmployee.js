import React, { Component } from 'react';
import axios from 'axios';
import Navbar1 from '../Navbars/Navbar1';
import Navbar2 from '../Navbars/Navbar2';
import AddEmployeeHeader from '../Headers/AddEmployeeHeader';
const globalNames = {
    APPURL : 'http://localhost:1234/'
}
class AddEmployee extends Component
{
    constructor(props) {
        super(props);
        this.state = {
            em_name: '',
            em_email: '',
            em_mobile : '',
            em_image : '',
            em_gender : '',
            em_status : 1,
            em_imagename : '',
            editempdata : {
              em_name : ''
            }
        };
      }
      componentDidMount()
      {
        if(this.props.data)
        {
          this.setState({
            editempdata : {
              em_name : this.props.data.em_name
            }
          })
        }
      }
      handleInputChange = e => {
        this.setState({
          [e.target.name]: e.target.value,
        });
      };
      convertBase64 = (file) => {
        return new Promise((resolve, reject) => {
          const fileReader = new FileReader();
          fileReader.readAsDataURL(file)
          fileReader.onload = () => {
            resolve(fileReader.result);
          }
          fileReader.onerror = (error) => {
            reject(error);
          }
        })
      }
      handleFileRead = async (event) => {
        const file = event.target.files[0]
        const base64 = await this.convertBase64(file)
        this.setState({
            em_image : base64,
            em_imagename : event.target.files[0].name
        });
      }
      handleSubmit = e => {
        e.preventDefault();
        const { em_name, em_email, em_mobile, em_image, em_gender, em_status, em_imagename } = this.state;
        var formData = {
            em_name,
            em_email,
            em_mobile,
            em_image,
            em_gender,
            em_status,
            em_imagename
        };
        return axios
          .post(globalNames.APPURL+'admin/save-employee', { ...formData },{
            header: {
                'Content-Type': 'application/json',
                'token' : localStorage.getItem('admintoken'),
                'id' : localStorage.getItem('adminid')
            }
        })
          .then((res) => {
            if(res.data.statuscode=="1"){
                alert("Employee Record Added Successfully!!");
                window.location.href='/admin/add-employee';
            }else{
                alert("Failed to Add Employee Record!!");
                window.location.href='/admin/add-employee';
            }
          })
          .catch(err => {
            console.error(err);
          });
      };
    render()
    {
        return (
            <div id="wrapper">
                <Navbar1 am_username={localStorage.getItem("adminusername")}/>
                <Navbar2/>
            <div id="page-wrapper">
                <AddEmployeeHeader/>
            <div id="page-inner">
            <div className="row">
            <div className="col-lg-12">
                <div className="card">
                <div className="card-action">
                    Add Employee Form
                </div>
                <div className="card-content">
                    <form onSubmit={(e)=>this.handleSubmit(e)} className="col s12">
                    <div className="row">
                        <div className="input-field col s12">
                          <p>Enter Name:</p>
                        <input value={this.state.editempdata.em_name} id="first_name" type="text" name="em_name" required onChange={this.handleInputChange} className="validate" required/>
                        </div>
                        
                        <div className="input-field col s12">
                        <p>Enter Email:</p>
                        <input id="last_name" type="email" name="em_email" required onChange={this.handleInputChange} className="validate" required/>
                        
                        </div>
                        <div className="input-field col s12">
                        <p>Enter Mobile:</p>
                        <input id="last_name" type="number" name="em_mobile" required onChange={this.handleInputChange} className="validate" required/>
                        
                        </div>
                        <div className="input-field col s12">
                        <input name="em_image" required onChange={this.handleFileRead} required type="file"/>
                        </div>
                        <div className="input-field col s12">
                        <select required name="em_gender" onChange={this.handleInputChange}  className="form-control" >
                        <option value="">Select Gender</option> 
                          <option value="1">Male</option>   
                          <option value="2">Female</option>
                      </select>
                        </div>
                        <div className="input-field col s12">
                        <input id="submit" type="submit" className="validate" />
                        </div>
                    </div>
                    </form>
                    <div className="clearBoth" />
                </div>
                </div>
            </div>	
            </div>
            </div>
            </div>
            </div>
        );
    }
}
export default AddEmployee;