import React, { Component } from 'react';
class FourZeroFour extends Component
{
    render()
    {
        return (
            <div className="col-md-12">
            <h1 style={{color : "#fff", margin : "20px", textAlign : "center"}}>Your are Un-Authorized to access contents of this URL.</h1>
            </div>
        );
    }
}
export default FourZeroFour;