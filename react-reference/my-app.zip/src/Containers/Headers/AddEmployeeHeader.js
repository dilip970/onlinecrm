import React, { Component } from 'react';
class AddEmployeeHeader extends Component
{
    render()
    {
        return (
            <div className="header"> 
                <h1 className="page-header">
                    Add Employee
                </h1>
                <ol className="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Add Employee</a></li>
                    <li className="active">Form</li>
                </ol> 					
            </div>
        );
    }
}
export default AddEmployeeHeader;