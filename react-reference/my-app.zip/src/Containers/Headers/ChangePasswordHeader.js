import React, { Component } from 'react';
class ChangePasswordHeader extends Component
{
    render()
    {
        return (
            <div className="header"> 
                <h1 className="page-header">
                    Change Password
                </h1>
                <ol className="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Change Password</a></li>
                    <li className="active">Form</li>
                </ol> 					
            </div>
        );
    }
}
export default ChangePasswordHeader;