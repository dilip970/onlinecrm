import React, { Component } from 'react';
import axios from 'axios';
import Dashboard from '../Dashboard/Dashboard';
import logo from '../../Images/usericon.png';
import './Login.css';
const globalNames = 
{
  APPURL : 'http://localhost:1234/'
}
class Login extends Component
{
  constructor(props) 
  {
    super(props);
    this.state = {
      am_username: '',
      am_password: '',
      isLoggedIn : '',
      am_id : ''
    };
  }
  handleInputChange = e => 
  {
    this.setState({
      [e.target.name]: e.target.value,
    });
  };
  handleSubmit = e => {
    e.preventDefault();
    const { am_username, am_password } = this.state;
    const loginCredentials = {
      am_username,
      am_password
    };
    return axios
      .post(globalNames.APPURL+'admin/login', { ...loginCredentials },{
        header: {
            'Content-Type': 'application/json'
        }
    })
      .then((res) => {
        if(res.data.login=="1"){
          localStorage.clear();
          localStorage.setItem('adminid',res.data.adminCredentials[0].am_id);
          localStorage.setItem('adminusername',res.data.adminCredentials[0].am_username);
          localStorage.setItem('admintoken',res.data.token);
          this.setState({
            isLoggedIn : "Logged In",
            am_username : res.data.adminCredentials[0].am_username,
            am_id : res.data.adminCredentials[0].am_id
          })
        }else{
          console.log("Unable to create admin session");
          alert("Login Failed!! Please check username and password and try again.");
        }
      })
      .catch(err => {
        console.error(err);
      });
  };
    render()
    {
      if(localStorage.getItem('adminid')==this.state.am_id)
      {
        window.location.href = '/admin/dashboard/'+this.state.am_id;
      }
      else
      {
        return (
          <div className="container">
          <div className="row">
            <div className="col-sm-6 col-md-4 col-md-offset-4">
              <h1 className="text-center login-title">ADMIN LOGIN</h1>
              <div className="account-wall">
                <img className="profile-img" src={logo} alt="" />
                <form onSubmit={(e)=>this.handleSubmit(e)} className="form-signin">
                  <input name="am_username" onChange={this.handleInputChange} type="text" className="form-control" placeholder="Email" required autofocus /><br></br>
                  <input name="am_password" onChange={this.handleInputChange} type="password" className="form-control" placeholder="Password" required />
                  <button style={{fontSize : '10px'}} className="btn btn-lg btn-primary btn-block" type="submit">
                    Login</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      );
      }
    }
}
export default Login;