import React, { Component } from 'react';
class Navbar2 extends Component
{
    Logout(e)
    {
        e.preventDefault();
        localStorage.clear();
        window.location.href='/admin/login';
    }
    render()
    {
        return (
            <nav className="navbar-default navbar-side" role="navigation">
                <div className="sidebar-collapse">
                    <ul className="nav" id="main-menu">
                    <li>
                        <a className="active-menu waves-effect waves-dark" href={'/admin/dashboard/' + localStorage.getItem("adminid")}><i className="fa fa-dashboard" /> Dashboard</a>
                    </li>
                    <li>
                        <a href="/admin/admins-list" className="waves-effect waves-dark"><i className="fa fa-users" /> Admins List</a>
                    </li>
                    <li>
                        <a href="/admin/add-employee" className="waves-effect waves-dark"><i className="fa fa-plus-square" /> Add Employee</a>
                    </li>
                    <li>
                        <a href="/admin/employees-list/0" className="waves-effect waves-dark"><i className="fa fa-users" /> Employees List</a>
                    </li>
                    
                    <li>
                        <a href="/admin/employees-list/1" className="waves-effect waves-dark"><i className="fa fa-users" /> Active Employees List</a>
                    </li>

                    <li>
                        <a href="/admin/employees-list/2" className="waves-effect waves-dark"><i className="fa fa-users" /> InActive Employees List</a>
                    </li>
                    <li>
                        <a href="/admin/change-password" className="waves-effect waves-dark"><i className="fa fa-gear fa-fw" /> Change Password</a>
                    </li>
                    <li>
                        <a href="#" onClick={(e) => this.Logout(e)} className="waves-effect waves-dark"><i className="fa fa-power-off" /> Logout </a>
                    </li>
                    </ul>
                </div>
            </nav>
        );
    }
}
export default Navbar2;