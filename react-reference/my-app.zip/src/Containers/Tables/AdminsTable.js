import React, { Component } from 'react';
import axios from 'axios';
import $ from 'jquery';
import Navbar1 from '../Navbars/Navbar1';
import Navbar2 from '../Navbars/Navbar2';
import AdminTableHeader from '../Headers/AdminTableHeader';
const globalNames = {
    APPURL : 'http://localhost:1234/'
}
class AdminTable extends Component
{
    constructor(props) {
        super(props);
        this.state = {
          admins : []
        };
    }
    componentDidMount()
    {
        
        return axios
        .get(globalNames.APPURL+'admin/admins-list/'+localStorage.getItem("adminid") ,{
          header: {
              'Content-Type': 'application/json',
              'token' : localStorage.getItem("admintoken")
          }
        })
        .then((res) => {  
            this.setState({
                admins : res.data
            });
            window.$('#dataTables-example').DataTable();
        })
        .catch(err => {
          console.error(err);
        });
    }
    render()
    {
        let list = this.state.admins;
        if(this.state.admins)
        {
            list = (
                <tbody>
                    {
                        this.state.admins.map((admin,key) => {
                            return <tr className="gradeU">
                            <td>{++key}</td>
                            <td>{admin.am_username}</td>
                            </tr>
                        })
                    }
                </tbody>
            );
        }
        return (
            <div id="wrapper">
                <Navbar1 am_username={localStorage.getItem("adminusername")}/>
                <Navbar2/>
            <div id="page-wrapper">
                <AdminTableHeader/>
            <div id="page-inner">
            <div className="row">
            <div className="col-md-12">
                <div className="card">
                <div className="card-action">
                    Admins List
                </div>
                <div className="card-content">
                    <div className="table-responsive">
                    <table className="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Admin Name</th>
                        </tr>
                        </thead>
                        {list}
                    </table>
                    </div>
                </div>
                </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        );
    }
}
export default AdminTable;