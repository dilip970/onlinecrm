import React, { Component } from 'react';
import axios from 'axios';
import $ from 'jquery';
import Navbar1 from '../Navbars/Navbar1';
import Navbar2 from '../Navbars/Navbar2';
import EmployeesTableHeader from '../Headers/EmployeesTableHeader';
import AddEmployee from '../Employees/AddEmployee';
const globalNames = {
    APPURL : 'http://localhost:1234/'
}
class AdminTable extends Component
{
    constructor(props) {
        super(props);
        this.state = {
          employees : [],
          empstatus : '',
          empid : '',
          editemployee : {}
        };
    }
    deleteEmployee = (em_id) => 
    {
        if(window.confirm('Are you sure?'))
        {
            return axios.delete(globalNames.APPURL+'admin/deleteEmployee'+'/'+em_id+'/'+window.location.href.substring(window.location.href.lastIndexOf('/') + 1), {
                headers : {
                    'Content-Type': 'application/json',
                    'token' : localStorage.getItem("admintoken"),
                    'id' : localStorage.getItem("adminid")
                }
            }).then((response) => {
                alert("Employee Deleted Successfully!!");
                this.setState({
                    employees : response.data[1]
                });
                window.$('#dataTables-example').DataTable();
            }).catch((err => {
                console.log(err);
            }))
        }
        else
        {
            window.location.reload();
        }
    }
    editEmployee = (em_id) => 
    {
        return axios.get(globalNames.APPURL+'admin/editEmployee'+'/'+em_id, {
            headers : {
                'Content-Type': 'application/json',
                'token' : localStorage.getItem("admintoken"),
                'id' : localStorage.getItem("adminid")
            }
        }).then((response) => {
            this.setState({
                editemployee : response.data[0]
            })
        }).catch((err => {
            console.log(err);
        }))
    }
    componentDidMount()
    {
        return axios
        .get(globalNames.APPURL+'admin/employees-list'+'/'+window.location.href.substring(window.location.href.lastIndexOf('/') + 1) ,{
            headers: {
              'Content-Type': 'application/json',
              'token' : localStorage.getItem("admintoken"),
              'id' : localStorage.getItem("adminid")
          }
        })
        .then((res) => {  
            this.setState({
                employees : res.data
            });
            window.$('#dataTables-example').DataTable();
        })
        .catch(err => {
          console.error(err);
        });
    }
    selectHandler = async(event) => {
        var data = event.target.value;
        var split = data.split(',');
        var empstatus = split[0];
        var empid = split[1];
        this.setState( () => ({
            empid : empid,
            empstatus : empstatus
          }), () => {
              if(window.confirm('Are you sure?')){
                return axios
                .patch(globalNames.APPURL+'admin/change-employee-status' , { empstatus : this.state.empstatus, empid : this.state.empid} ,{
                headers: {
                    'Content-Type': 'application/json',
                    'token' : localStorage.getItem("admintoken"),
                    'id' : localStorage.getItem("adminid")
                }
                })
                .then((res) => {  
                    if(res.status==200){
                        window.alert("Employee Status Updated Successfully");
                    }else{
                        window.alert("Something went Wrong!!");
                        window.location.reload();
                    }
                })
                .catch(err => {
                    console.error(err);
                });
              }
              else{
                  window.location.reload();
              }
          })
    }
    render()
    {
        if(Object.keys(this.state.editemployee).length)
        {
            return (
                <AddEmployee data={this.state.editemployee}/>
            );
        }
        else
        {
            let list = this.state.employees;
        if(this.state.employees)
        {
            let style = {
                width : "100px",
                heigth : "100px"
            }
            list = (
                <tbody>
                    {
                        this.state.employees.map((employee,key) => {
                            return <tr className="gradeU">
                            <td>{++key}</td>
                            <td>{employee.em_name}</td>
                            <td>{employee.em_email}</td>
                            <td>{employee.em_mobile}</td>
                            <td><img style={style} src={globalNames.APPURL+'files/'+employee.em_image} /></td>
                            <td>{
                                (employee.em_gender==1) ? 'Male' : 'Female'
                            }</td>
                            <td>{(employee.em_status==1) ? 'Active' : 'Inactive'}</td>
                            <td><a onClick={() => this.editEmployee(employee.em_id)} href="javascript:void(0);"><i className="fa fa-pencil"></i></a></td>
                            <td><a onClick={() => this.deleteEmployee(employee.em_id)} href="javascript:void(0);"><i style= {{color : "#F1411B"} } className="fa fa-trash-o"></i></a></td>
                            <td><select name="empstatus" onChange={this.selectHandler} className="form-control">
                                <option selected={employee.em_status == 1 ? true : false} value={["1" , employee.em_id]}>Active</option>
                                <option selected={employee.em_status == 2 ? true : false} value={["2" , employee.em_id]}>In-Active</option>
                                </select></td>
                            </tr>
                        })
                    }
                </tbody>
            );
        }
        return (
            <div id="wrapper">
                <Navbar1 am_username={localStorage.getItem("adminusername")}/>
                <Navbar2/>
            <div id="page-wrapper">
                <EmployeesTableHeader/>
            <div id="page-inner">
            <div className="row">
            <div className="col-md-12">
                <div className="card">
                <div className="card-action">
                    Employees List
                </div>
                <div className="card-content">
                    <div className="table-responsive">
                    <table className="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                        <tr>
                            <th>S.No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Image</th>
                            <th>Gender</th>
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        {list}
                    </table>
                    </div>
                </div>
                </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        );
        }
    }
}
export default AdminTable;